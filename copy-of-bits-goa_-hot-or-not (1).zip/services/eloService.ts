import { EloResult } from '../types';

const K_FACTOR = 32;

export const calculateElo = (winnerRating: number, loserRating: number): EloResult => {
  // Calculate expected scores
  // E_a = 1 / (1 + 10 ^ ((R_b - R_a) / 400))
  const expectedScoreWinner = 1 / (1 + Math.pow(10, (loserRating - winnerRating) / 400));
  const expectedScoreLoser = 1 / (1 + Math.pow(10, (winnerRating - loserRating) / 400));

  // Update ratings
  // R' = R + K * (S - E)
  // S is 1 for winner, 0 for loser
  const newRatingWinner = Math.round(winnerRating + K_FACTOR * (1 - expectedScoreWinner));
  const newRatingLoser = Math.round(loserRating + K_FACTOR * (0 - expectedScoreLoser));

  return {
    newRatingWinner,
    newRatingLoser,
    expectedScoreWinner,
    expectedScoreLoser
  };
};
