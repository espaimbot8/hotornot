import { GoogleGenAI } from "@google/genai";

// Helper to safely get key
const getApiKey = () => {
  try {
    return process.env.API_KEY;
  } catch (e) {
    return undefined;
  }
};

let ai: GoogleGenAI | null = null;

const getAiClient = () => {
  if (ai) return ai;
  
  const key = getApiKey();
  if (key) {
    ai = new GoogleGenAI({ apiKey: key });
    return ai;
  }
  return null;
};

export const generateRoastOrPraise = async (winnerName: string, loserName: string, winnerMajor: string): Promise<string> => {
  const client = getAiClient();
  if (!client) return "Too hot to handle! 🔥";

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Write a spicy, cheeky, Gen-Z style one-sentence comment about ${winnerName} (Major: ${winnerMajor}) being voted "hotter" than ${loserName} at BITS Goa. 
      Use BITS Goa specific slang like "Lite", "Macha", "Ghot", "NC", "Sky Lawns", "Bogmalo", "Totem", "Dulaar". 
      Make it sound like campus gossip. Keep it under 15 words.`,
    });
    return response.text || "Heat level rising! 🔥";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Heat level rising! 🔥";
  }
};

export const generateBio = async (name: string, major: string, year: string): Promise<string> => {
  const client = getAiClient();
  if (!client) return "Mystery hottie on campus.";

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Write a short, flirty or cool bio (under 80 chars) for a student named ${name} (${major}, ${year} year) at BITS Goa. 
      Reference things like "Maggi at NC", "B-Dome nights", "Zuari breeze", or "Grabbing a QP".`,
    });
    return response.text || "Just spotting cuties at the cafeteria.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Just spotting cuties at the cafeteria.";
  }
};