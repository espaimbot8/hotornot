import React, { useState } from 'react';
import { Profile } from '../types';
import { generateBio } from '../services/geminiService';
import { UserPlus, Flame, Loader2, Camera } from 'lucide-react';

interface AddProfileProps {
  onAdd: (profile: Profile) => void;
}

const AddProfile: React.FC<AddProfileProps> = ({ onAdd }) => {
  const [name, setName] = useState('');
  const [major, setMajor] = useState('');
  const [year, setYear] = useState('1st');
  const [tags, setTags] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !major) return;

    setLoading(true);

    // Generate a random seed for the image using unsplash source for better looking people
    // Using gender neutral query terms to get people generally
    const generatedBio = await generateBio(name, major, year);

    const newProfile: Profile = {
      id: Date.now().toString(),
      name,
      major,
      year,
      // Using unsplash source for distinct portraits
      image: `https://source.unsplash.com/random/400x500/?portrait,student,${Date.now()}`, 
      rating: 1200,
      wins: 0,
      losses: 0,
      matches: 0,
      bio: generatedBio,
      tags: tags.split(',').map(t => t.trim()).filter(Boolean).slice(0, 3)
    };

    // Fallback image if source.unsplash is acting up in preview, use a reliable one
    if (Math.random() > 0.5) {
         newProfile.image = `https://images.unsplash.com/photo-${Math.random() > 0.5 ? '1500648767791-00dcc994a43e' : '1534528741775-53994a69daeb'}?w=500&auto=format&fit=crop&q=60&random=${Date.now()}`;
    }

    onAdd(newProfile);
    setLoading(false);
  };

  return (
    <div className="flex items-center justify-center min-h-[80vh] p-4 animate-fade-in">
      <div className="bg-bits-card w-full max-w-md p-8 rounded-3xl border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-bits-red via-bits-hot to-bits-yellow"></div>
        
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-bits-red/10 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-bits-red/20">
            <Camera className="w-10 h-10 text-bits-red" />
          </div>
          <h2 className="text-3xl font-black italic text-white tracking-tighter">ADD A <span className="text-bits-red">HOTTIE</span></h2>
          <p className="text-gray-400 text-sm mt-2">Expose your wingman or hype up your bestie. Let the campus decide.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-1">
            <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Name</label>
            <input 
              type="text" 
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold focus:border-bits-red focus:outline-none focus:ring-1 focus:ring-bits-red transition-all placeholder-gray-700"
              placeholder="e.g. That guy from the library"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Year</label>
              <select 
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold focus:border-bits-red focus:outline-none appearance-none"
              >
                <option value="1st">1st Year</option>
                <option value="2nd">2nd Year</option>
                <option value="3rd">3rd Year</option>
                <option value="4th">4th Year</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Branch</label>
              <input 
                type="text" 
                required
                value={major}
                onChange={(e) => setMajor(e.target.value)}
                className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold focus:border-bits-red focus:outline-none placeholder-gray-700"
                placeholder="e.g. CS, EEE"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 ml-1">Vibe Tags</label>
            <input 
              type="text" 
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              className="w-full bg-black border border-white/10 rounded-xl p-4 text-white font-bold focus:border-bits-red focus:outline-none placeholder-gray-700"
              placeholder="e.g. Gym, Musician, Model"
            />
          </div>

          <button 
            type="submit" 
            disabled={loading}
            className="w-full mt-4 bg-bits-red hover:bg-red-600 text-white font-black text-lg italic py-4 rounded-xl shadow-lg shadow-bits-red/20 transform transition hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 uppercase tracking-wider"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Cooking...</span>
              </>
            ) : (
              <>
                <Flame className="w-5 h-5 fill-current" />
                <span>Upload Hottie</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddProfile;