import React from 'react';
import { View } from '../types';
import { Flame, Trophy, UserPlus, Gavel } from 'lucide-react';

interface NavbarProps {
  currentView: View;
  setView: (view: View) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView }) => {
  return (
    <nav className="fixed bottom-0 w-full bg-black/80 backdrop-blur-xl border-t border-white/10 z-50 pb-safe md:top-0 md:bottom-auto md:border-b md:border-t-0 h-16 md:h-20">
      <div className="max-w-6xl mx-auto px-6 h-full flex items-center justify-between">
        <div className="hidden md:flex items-center gap-2 cursor-pointer" onClick={() => setView('VOTE')}>
          <div className="bg-bits-red text-white font-black px-2 py-1 italic text-xl tracking-tighter transform -skew-x-12">BITS</div>
          <span className="font-black text-2xl tracking-tighter italic text-white">MASH</span>
        </div>

        <div className="flex w-full md:w-auto items-center justify-evenly md:gap-12">
          <button 
            onClick={() => setView('VOTE')}
            className={`flex flex-col md:flex-row items-center gap-1.5 p-2 transition-all duration-300 ${currentView === 'VOTE' ? 'text-bits-red scale-110' : 'text-gray-500 hover:text-gray-300'}`}
          >
            <Gavel className={`w-6 h-6 md:w-5 md:h-5 ${currentView === 'VOTE' && 'fill-current animate-pulse-fast'}`} />
            <span className="text-[10px] md:text-sm font-bold uppercase tracking-widest">Judge</span>
          </button>

          <button 
            onClick={() => setView('LEADERBOARD')}
            className={`flex flex-col md:flex-row items-center gap-1.5 p-2 transition-all duration-300 ${currentView === 'LEADERBOARD' ? 'text-bits-yellow scale-110' : 'text-gray-500 hover:text-gray-300'}`}
          >
            <Trophy className={`w-6 h-6 md:w-5 md:h-5 ${currentView === 'LEADERBOARD' && 'fill-current'}`} />
            <span className="text-[10px] md:text-sm font-bold uppercase tracking-widest">Hot List</span>
          </button>

          <button 
            onClick={() => setView('ADD_PROFILE')}
            className={`flex flex-col md:flex-row items-center gap-1.5 p-2 transition-all duration-300 ${currentView === 'ADD_PROFILE' ? 'text-white scale-110' : 'text-gray-500 hover:text-gray-300'}`}
          >
            <UserPlus className={`w-6 h-6 md:w-5 md:h-5 ${currentView === 'ADD_PROFILE' && 'fill-current'}`} />
            <span className="text-[10px] md:text-sm font-bold uppercase tracking-widest">Add Hottie</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;