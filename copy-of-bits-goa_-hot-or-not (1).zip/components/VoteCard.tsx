import React from 'react';
import { Profile } from '../types';
import { Flame } from 'lucide-react';

interface VoteCardProps {
  profile: Profile;
  onVote: (id: string) => void;
  disabled: boolean;
}

const VoteCard: React.FC<VoteCardProps> = ({ profile, onVote, disabled }) => {
  const handleClick = (e: React.MouseEvent) => {
    if (!disabled) {
      onVote(profile.id);
    }
  };

  const handleButtonClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent double triggering if bubbling occurs
    if (!disabled) {
      onVote(profile.id);
    }
  };

  return (
    <div 
      onClick={handleClick}
      className="relative w-full max-w-[340px] aspect-[3/4] group perspective-1000 cursor-pointer active:scale-95 transition-transform duration-100"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/90 rounded-3xl z-10 pointer-events-none"></div>
      
      {/* Main Card */}
      <div className="relative h-full w-full bg-bits-card rounded-3xl overflow-hidden border-2 border-white/5 shadow-2xl transition-all duration-500 hover:shadow-bits-red/20">
        <img 
          src={profile.image} 
          alt={profile.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 grayscale-[20%] group-hover:grayscale-0"
        />
        
        {/* Info Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-5 z-20 flex flex-col gap-2">
          <div>
            <h3 className="text-2xl font-black text-white uppercase tracking-tight leading-none">{profile.name}</h3>
            <p className="text-bits-yellow font-bold text-sm flex items-center gap-2 mt-1">
              {profile.major} <span className="w-1 h-1 bg-white rounded-full"></span> {profile.year} Year
            </p>
          </div>
          
          <div className="flex flex-wrap gap-2 my-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-75">
             {profile.tags.map(tag => (
               <span key={tag} className="text-[10px] font-bold uppercase px-2 py-1 bg-white/10 backdrop-blur-md border border-white/10 rounded text-gray-200">
                 {tag}
               </span>
             ))}
          </div>
        </div>

        {/* Rating Badge */}
        <div className="absolute top-4 left-4 bg-black/40 backdrop-blur-md border border-white/10 px-3 py-1 rounded-full text-xs font-bold text-white flex items-center gap-1 z-20">
          <Flame className="w-3 h-3 text-bits-red fill-bits-red" /> {profile.rating}
        </div>
      </div>

      {/* Action Button */}
      <button
        onClick={handleButtonClick}
        disabled={disabled}
        className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 z-30 bg-gradient-to-r from-bits-red to-red-600 text-white w-[85%] py-3 rounded-xl font-black text-lg uppercase tracking-widest shadow-lg hover:scale-105 active:scale-95 transition-all border-2 border-bits-black group-hover:shadow-bits-red/50 flex items-center justify-center gap-2"
      >
        <span>HOT</span> <Flame className="w-5 h-5 fill-white animate-pulse" />
      </button>
    </div>
  );
};

export default VoteCard;