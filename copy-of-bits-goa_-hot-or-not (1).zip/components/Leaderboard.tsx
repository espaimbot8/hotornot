import React from 'react';
import { Profile } from '../types';
import { Flame, TrendingUp, Zap } from 'lucide-react';

interface LeaderboardProps {
  profiles: Profile[];
}

const Leaderboard: React.FC<LeaderboardProps> = ({ profiles }) => {
  const sortedProfiles = [...profiles].sort((a, b) => b.rating - a.rating);

  return (
    <div className="w-full max-w-4xl mx-auto p-4 pb-24 animate-fade-in">
      <div className="mb-6 text-center md:text-left">
        <h2 className="text-4xl font-black italic text-white tracking-tighter flex items-center justify-center md:justify-start gap-3">
          <span className="text-bits-red">THE HEAT</span> LIST <Flame className="w-8 h-8 text-bits-red fill-bits-red animate-bounce-short" />
        </h2>
        <p className="text-gray-400 font-medium">Top ranked hotties on campus right now.</p>
      </div>

      <div className="bg-bits-card/50 backdrop-blur-lg rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-gray-500 text-xs font-bold uppercase tracking-widest">
                <th className="p-5 text-center w-20">Rank</th>
                <th className="p-5">Legend</th>
                <th className="p-5 text-center">Rating</th>
                <th className="p-5 text-center hidden sm:table-cell">W/L</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {sortedProfiles.map((profile, index) => {
                const winRate = profile.matches > 0 ? Math.round((profile.wins / profile.matches) * 100) : 0;
                const isTop3 = index < 3;
                
                return (
                  <tr key={profile.id} className="hover:bg-white/5 transition-colors group">
                    <td className="p-4 text-center font-black italic text-xl relative">
                      {index === 0 && <span className="text-4xl drop-shadow-lg">👑</span>}
                      {index === 1 && <span className="text-3xl text-gray-300">🥈</span>}
                      {index === 2 && <span className="text-3xl text-amber-700">🥉</span>}
                      {index > 2 && <span className="text-gray-600">#{index + 1}</span>}
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-4">
                        <div className={`relative w-14 h-14 rounded-xl overflow-hidden border-2 ${isTop3 ? 'border-bits-red shadow-lg shadow-bits-red/20' : 'border-white/10'}`}>
                          <img src={profile.image} alt={profile.name} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <div className="font-bold text-white text-lg flex items-center gap-2">
                            {profile.name}
                            {winRate > 70 && <Zap className="w-4 h-4 text-yellow-400 fill-yellow-400" />}
                          </div>
                          <div className="text-xs text-gray-400 flex gap-2 items-center">
                             <span className="bg-white/10 px-1.5 rounded text-white/80">{profile.major}</span>
                             <span>•</span>
                             <span>{profile.year} Year</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-center">
                      <div className="inline-flex flex-col items-center">
                        <span className={`text-xl font-black italic ${isTop3 ? 'text-bits-red' : 'text-white'}`}>
                          {profile.rating}
                        </span>
                        <span className="text-[10px] text-green-400 flex items-center gap-0.5">
                          <TrendingUp className="w-3 h-3" /> ELO
                        </span>
                      </div>
                    </td>
                    <td className="p-4 text-center text-gray-400 hidden sm:table-cell font-mono text-sm">
                      <span className="text-green-400">{profile.wins}W</span> - <span className="text-red-400">{profile.losses}L</span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;